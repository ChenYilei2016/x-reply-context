(() => {
  const profileFields=["baseUrl","apiKey","model","serviceTier","reasoningEffort"];
  const numericFields=["typingDelayMin","typingDelayMax","maxReplyLength"];
  const promptFields=["generatePrompt","rewritePrompt","polishPrompt"];
  const get=id=>document.getElementById(id);
  const status=get("status");
  let config,selectedId,dirty=false,saving=false;
  async function send(message) {
    const response=await chrome.runtime.sendMessage(message);
    if(!response?.ok)throw new Error(response?.error || "扩展连接失败，请重新打开设置。");
    return response;
  }
  function remember() {
    const profile=config.profiles.find(item=>item.id===selectedId);
    if(!profile)return;
    profile.name=get("profileName").value;
    for(const field of profileFields)profile[field]=get(field).value;
  }
  function renderProcessing() {
    const supported=XReplyAIConfig.isOpenAI(get("baseUrl").value);
    get("openaiMode").hidden=!supported;get("serviceTier").disabled=!supported||saving;get("reasoningEffort").disabled=!supported||saving;
  }
  function renderEndpoint() {
    const value=get("baseUrl").value.trim(),preview=get("endpointPreview"),warning=get("baseUrlWarning");
    let address="",hint="";
    if(value){
      try {
        const base=new URL(value);
        address=XReplyAIConfig.endpoint(base).href;
        if(!base.pathname.replace(/\/+$/,""))hint="只填了域名。使用 New API 时，请在域名后加 /v1。";
      } catch {
        hint="请输入有效的模型接口地址。";
      }
    }
    preview.querySelector("code").textContent=address;
    preview.hidden=!address;
    warning.textContent=hint;
    warning.hidden=!hint;
  }
  /** 创作步骤的 API 选择框，首次读取配置时创建。 */
  function renderCreationSteps() {
    get("creationProfiles").replaceChildren(...XReplyAIConfig.creationSteps.flatMap(step=>{
      const label=document.createElement("label");
      label.htmlFor=`creationProfile-${step.id}`;label.textContent=`${step.label} API`;
      const select=document.createElement("select");
      select.id=`creationProfile-${step.id}`;
      return [label,select];
    }));
  }
  const creationSelect=step=>get(`creationProfile-${step.id}`);
  function renderCreationOptions(profileOptions) {
    for(const step of XReplyAIConfig.creationSteps){
      const select=creationSelect(step),value=select.value;
      select.replaceChildren(new Option("跟随当前配置",""),...profileOptions());
      select.value=config.profiles.some(profile=>profile.id===value) ? value : "";
    }
  }
  const creationProfileIds=()=>Object.fromEntries(XReplyAIConfig.creationSteps.map(step=>[step.id,creationSelect(step).value]));
  function renderProfiles() {
    const profileOptions = () => config.profiles.map(profile=>new Option(profile.name || "未命名配置",profile.id));
    renderCreationOptions(profileOptions);
    const polish = get("polishProfile"), polishId = polish.value;
    polish.replaceChildren(new Option("请选择 API 配置",""),...profileOptions());
    polish.value = config.profiles.some(profile=>profile.id===polishId) ? polishId : "";
    get("profile").replaceChildren(...profileOptions());
    get("profile").value=selectedId;
    const profile=config.profiles.find(item=>item.id===selectedId);
    get("profileName").value=profile.name;
    for(const field of profileFields)get(field).value=profile[field] ?? (["serviceTier","reasoningEffort"].includes(field)?"auto":"");
    renderProcessing();
    renderEndpoint();
    get("removeProfile").disabled=config.profiles.length<=1;
    get("addProfile").disabled=config.profiles.length>=10;
  }
  function changed(text="修改尚未保存，点击保存后应用。") {dirty=true;status.textContent=text;}
  function applied(value) {
    const selected=value.profiles.find(item=>item.id===value.activeProfileId);
    const polish=XReplyAIConfig.polishProfile(value);
    const creation=XReplyAIConfig.creationSteps.filter(step=>value.creationProfileIds[step.id])
      .map(step=>` · ${step.label} ${XReplyAIConfig.creationProfile(value,step.id).name}`).join("");
    get("activeProfile").textContent=`已保存的当前配置 ${selected.name} · AI ${value.enabled?"已开启":"已关闭"}${polish ? ` · 润色 ${polish.name}` : ""}${creation}`;
  }
  void send({type:"AI_CONFIG_GET"}).then(({config:value})=>{
    config=value;selectedId=value.activeProfileId;
    for(const field of promptFields)get(field).value=config[field];
    for(const field of numericFields)get(field).value=config[field];
    get("enabled").checked=config.enabled;
    get("polishEnabled").checked=config.polishEnabled;
    get("polishSettings").open=config.polishEnabled;
    for(const id of ["save","profile","addProfile","openaiProfile","removeProfile"])get(id).disabled=false;
    renderCreationSteps();renderProfiles();get("polishProfile").value=config.polishProfileId;
    for(const step of XReplyAIConfig.creationSteps)creationSelect(step).value=config.creationProfileIds[step.id];
    get("imageModel").value=config.imageModel;get("imageQuality").value=config.imageQuality;
    get("creationSettings").open=Object.values(config.creationProfileIds).some(Boolean);
    applied(config);status.textContent="";
  }).catch(error=>{status.textContent=error.message;});
  get("settings").addEventListener("input",event=>{
    if(!config)return;
    changed();
    if(event.target===get("baseUrl")){
      renderProcessing();
      renderEndpoint();
    }
  });
  for(const field of ["serviceTier","reasoningEffort"])get(field).addEventListener("change",()=>{if(config)changed();});
  get("profile").addEventListener("change",()=>{
    remember();selectedId=get("profile").value;renderProfiles();changed("已选择配置，点击保存后切换生效。尚未保存的编辑保留在本页。");
  });
  get("addProfile").addEventListener("click",()=>{
    if(!config || saving || config.profiles.length>=10)return;
    remember();selectedId=crypto.randomUUID();config.profiles.push({id:selectedId,name:"新配置",baseUrl:"",apiKey:"",model:"",serviceTier:"auto",reasoningEffort:"auto"});
    renderProfiles();changed();get("profileName").focus();
  });
  get("openaiProfile").addEventListener("click",()=>{
    if(!config || saving)return;
    remember();let profile=config.profiles.find(item=>item.id==="openai");
    if(!profile){
      if(config.profiles.length>=10){status.textContent="最多保存10组，请先删除不需要的配置。";return;}
      profile={...XReplyAIConfig.openAIPreset};config.profiles.push(profile);
    }
    selectedId=profile.id;renderProfiles();changed("已选择 OpenAI 配置；已有 Key 和自定义值不会被覆盖。填写完成后保存生效。");
  });
  get("removeProfile").addEventListener("click",()=>{
    if(!config || saving || config.profiles.length<=1)return;
    config.profiles=config.profiles.filter(item=>item.id!==selectedId);selectedId=config.profiles[0].id;
    renderProfiles();changed("已从本页移除此配置；保存后才删除，关闭本页可放弃这次修改。");
  });
  get("defaults").addEventListener("click",()=>{
    for(const field of promptFields)get(field).value=XReplyAIConfig.defaults[field];
    changed("已填入默认 Prompt，点击保存后应用。");
  });
  get("settings").addEventListener("submit",async event=>{
    event.preventDefault();if(!config || saving)return;
    saving=true;remember();
    const controls=[...get("settings").querySelectorAll("input,textarea,select,button")];
    controls.forEach(control=>{control.disabled=true;});
    try {
      const next=XReplyAIConfig.normalizeProfiles({...config,enabled:get("enabled").checked,activeProfileId:selectedId,
        polishEnabled:get("polishEnabled").checked,polishProfileId:get("polishProfile").value,creationProfileIds:creationProfileIds(),
        imageModel:get("imageModel").value,imageQuality:get("imageQuality").value,
        ...Object.fromEntries(promptFields.map(field=>[field,get(field).value])),
        ...Object.fromEntries(numericFields.map(field=>[field,get(field).valueAsNumber]))});
      const origins=XReplyAIConfig.requiredOrigins(next);
      if(origins.length && !await chrome.permissions.request({origins}))throw new Error("域名未授权，设置未保存；原配置仍然生效。");
      await send({type:"AI_CONFIG_SAVE",config:next});
      config=next;dirty=false;applied(config);status.textContent="已保存并切换，旧配置的生成任务已取消。";
    } catch(error){status.textContent=error.message;}
    finally{saving=false;controls.forEach(control=>{control.disabled=false;});renderProfiles();}
  });
  window.addEventListener("beforeunload",event=>{if(dirty){event.preventDefault();event.returnValue="";}});
})();
