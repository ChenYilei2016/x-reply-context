/* One foreground run, one timer, no polling or persisted execution state. */
(() => {
  "use strict";
  const KEY="timedReplies";
  const defaults={enabled:false,minSeconds:10,maxSeconds:20,maxAttempts:500,maxMinutes:60};
  function normalize(raw) {
    const value={enabled:raw?.enabled===true};
    for(const [key,min,max] of [["minSeconds",10,3600],["maxSeconds",10,3600],["maxAttempts",1,500],["maxMinutes",1,240]]) {
      value[key]=raw?.[key] ?? defaults[key];
      if(!Number.isInteger(value[key]) || value[key]<min || value[key]>max)throw new Error("间隔需10～3600秒，次数1～500，时长1～240分钟，均为整数。");
    }
    if(value.minSeconds>value.maxSeconds)throw new Error("最短间隔不能大于最长间隔。");
    return value;
  }
  function create({storage,readState,trigger,requestRefresh}) {
    let config={...defaults},loaded=false,run=null,armed=null,timer=null,scheduledAt=0;
    let row=null,caption="尚未开始",attempts=0,firing=false;
    function paint() {
      if(row && !row.isConnected)row=null;
      if(!row)return;
      const status=row.querySelector('span'),button=row.querySelector('button');
      const text=!loaded?"定时回复：读取设置…":!config.enabled?"定时回复：已关闭":
        `定时 ${attempts}/${config.maxAttempts} · ${caption}`;
      if(status.textContent!==text)status.textContent=text;
      const label=run?"停止本轮":"开始本轮";
      if(button.textContent!==label)button.textContent=label;
      const disabled=!loaded||!config.enabled||Boolean(readState()?.reason);
      if(button.disabled!==disabled)button.disabled=disabled;
      const title=`随机${config.minSeconds}～${config.maxSeconds}秒，最多${config.maxAttempts}次或${config.maxMinutes}分钟。开始后会发送已填好的草稿；不会自行请求AI。`;
      if(row.title!==title)row.title=title;
    }
    function clearTimer(){clearTimeout(timer);timer=null;scheduledAt=0;}
    function stop(reason="已手动停止") {
      if(!run)return;
      run=null;armed=null;clearTimer();caption=reason;paint();requestRefresh();
    }
    function schedule(at) {
      if(timer!==null && scheduledAt===at)return;
      clearTimer();scheduledAt=at;
      timer=setTimeout(tick,Math.max(0,at-performance.now()));
    }
    function stateForRun() {
      const state=readState();
      if(!state || state.reason || !state.supported || state.session!==run.session || state.account!==run.account){
        stop(state?.reason || "页面或账号变化，已停止");return null;
      }
      return state;
    }
    function refresh() {
      if(!run || firing){paint();return;}
      if(performance.now()>=run.endAt){stop("已到时长上限");return;}
      const state=stateForRun();if(!state)return;
      if(armed && (armed.id!==state.id || armed.draft!==state.draft || !state.ready)){
        stop("草稿或回复状态变化，已停止");return;
      }
      if(!armed && state.ready && state.id!==run.lastId) {
        const seconds=config.minSeconds+Math.floor(Math.random()*(config.maxSeconds-config.minSeconds+1));
        armed={id:state.id,draft:state.draft,at:performance.now()+seconds*1000};
        caption=`本次等待${seconds}秒`;
      } else if(!armed)caption=state.waiting || "等待已填好的草稿";
      schedule(Math.min(armed?.at ?? run.endAt,run.endAt));paint();
    }
    function tick() {
      timer=null;scheduledAt=0;
      if(!run)return;
      if(performance.now()>=run.endAt){stop("已到时长上限");return;}
      const state=stateForRun();if(!state)return;
      if(!armed || performance.now()<armed.at){refresh();return;}
      if(!state.ready || state.id!==armed.id || state.draft!==armed.draft){stop("草稿或回复状态变化，未发送");return;}
      const owner=run;
      owner.lastId=state.id;attempts++;armed=null;firing=true;
      let sent=false;
      try {sent=trigger(state)===true;} catch { /* Do not retry an uncertain native action. */ }
      finally {firing=false;}
      if(run!==owner)return;
      if(!sent){stop("未确认触发，已停止；请核对结果");return;}
      if(attempts>=config.maxAttempts){stop("已到次数上限");return;}
      refresh();requestRefresh();
    }
    function start() {
      if(run || !loaded || !config.enabled)return;
      const state=readState();
      if(!state?.supported || state.reason){caption=state?.reason || "请从为你推荐打开回复框";paint();return;}
      attempts=0;run={session:state.session,account:state.account,lastId:"",endAt:performance.now()+config.maxMinutes*60000};
      refresh();requestRefresh();
    }
    function apply(value) {
      try {
        const next=normalize(value);
        if(JSON.stringify(next)!==JSON.stringify(config))stop("设置已变更，请重新开始");
        config=next;
      } catch {stop("设置无效，已停止");config={...defaults};}
      loaded=true;paint();requestRefresh();
    }
    storage.onChanged.addListener((changes,area)=>{if(area==="local"&&changes[KEY])apply(changes[KEY].newValue);});
    void storage.local.get(KEY).then(saved=>{if(!loaded)apply(saved[KEY]);},()=>{loaded=true;caption="设置读取失败";paint();});
    document.addEventListener("visibilitychange",()=>{if(document.hidden)stop("页面切到后台，已停止");});
    window.addEventListener("blur",()=>stop("页面失去焦点，已停止"));
    window.addEventListener("pagehide",()=>stop("页面已离开"));
    document.addEventListener("input",event=>{
      if(run && event.isTrusted && event.target instanceof Element && event.target.closest('[contenteditable="true"][data-testid^="tweetTextarea_"]'))stop("手动编辑草稿，已停止");
    },true);
    document.addEventListener("compositionstart",event=>{
      if(run && event.target instanceof Element && event.target.closest('[contenteditable="true"][data-testid^="tweetTextarea_"]'))stop("正在编辑草稿，已停止");
    },true);
    function render(s,bar) {
      if(s.feed!=="home" || s.homeTabIndex!==0)return;
      row=bar.querySelector('.xrc-timed-replies');
      if(!row){
        row=document.createElement('div');row.className='xrc-timed-replies';
        const status=document.createElement('span'),button=document.createElement('button');status.setAttribute('role','status');button.type='button';
        button.addEventListener('mousedown',event=>event.preventDefault());
        button.addEventListener('click',event=>{event.stopPropagation();if(run)stop();else start();});
        row.append(status,button);bar.append(row);
      }
      paint();
    }
    return {start,stop,refresh,render};
  }
  async function installSettings(storage) {
    const form=document.querySelector('#timed-reply-settings');if(!form)return;
    const status=form.querySelector('[role="status"]');
    const fields=['enabled','minSeconds','maxSeconds','maxAttempts','maxMinutes'];
    const input=key=>form.querySelector(`[name="${key}"]`);
    try {
      const saved=normalize((await storage.local.get(KEY))[KEY]);
      for(const key of fields){if(key==='enabled')input(key).checked=saved[key];else input(key).value=saved[key];}
      form.querySelectorAll('input,button').forEach(node=>{node.disabled=false;});
    }catch {status.textContent='设置读取失败，请重新打开扩展。';return;}
    form.addEventListener('input',()=>{status.textContent='修改尚未保存。';});
    form.addEventListener('submit',async event=>{
      event.preventDefault();const controls=[...form.querySelectorAll('input,button')];controls.forEach(node=>{node.disabled=true;});
      try {
        const value=normalize(Object.fromEntries(fields.map(key=>[key,key==='enabled'?input(key).checked:input(key).valueAsNumber])));
        await storage.local.set({[KEY]:value});status.textContent=value.enabled?'已保存；在为你推荐回复框点击“开始本轮”。':'已保存并关闭定时触发。';
      }catch(error){status.textContent=error.message || '设置未保存，请重试。';}
      finally{controls.forEach(node=>{node.disabled=false;});}
    });
  }
  globalThis.XReplyTimedReplies={defaults,normalize,create,installSettings};
})();
