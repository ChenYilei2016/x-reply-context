(() => {
  "use strict";
  const core = globalThis.XReplyContext;
  const CHANNEL = "x-reply-context-v1";
  const MAX_BYTES = 8 * 1024 * 1024;
  const pendingUsers = new Map();
  const pendingTweets = new Map();
  let ready = false;
  let timer;

  function relevantUrl(value) {
    try {
      const url = new URL(value, location.href);
      if (url.origin !== location.origin) return false;
      return /^\/i\/api\/2\/notifications\/(?:all|mentions|verified)\.json$/.test(url.pathname) ||
        /^\/i\/api\/graphql\/[\w-]+\/(?:TweetDetail|TweetResultByRestId|TweetResultsByRestIds|UserTweets|UserTweetsAndReplies|UserByScreenName|HomeTimeline|HomeLatestTimeline|SearchTimeline|CreateTweet)$/.test(url.pathname);
    } catch { return false; }
  }

  function flush() {
    timer = undefined;
    if (!ready || (!pendingTweets.size && !pendingUsers.size)) return;
    window.postMessage({
      channel: CHANNEL, type: "OBSERVED",
      batch: { users: [...pendingUsers.values()], tweets: [...pendingTweets.values()] }
    }, location.origin);
    pendingUsers.clear();
    pendingTweets.clear();
  }

  function accept(payload) {
    try {
      const batch = core.extract(payload);
      for (const user of batch.users) {
        if (pendingUsers.size < 500 || pendingUsers.has(user.id)) pendingUsers.set(user.id,user);
      }
      for (const tweet of batch.tweets) {
        if (pendingTweets.size < 500 || pendingTweets.has(tweet.id)) pendingTweets.set(tweet.id,tweet);
      }
      if (!timer) timer = setTimeout(flush,200);
    } catch {
      // A changed X response must not interfere with the original request.
    }
  }

  window.addEventListener("message", event => {
    if (event.source === window && event.origin === location.origin &&
        event.data?.channel === CHANNEL && event.data.type === "READY") {
      ready = true;
      flush();
    }
  });
  window.postMessage({ channel:CHANNEL,type:"OBSERVER_READY" },location.origin);

  async function readResponse(response) {
    if (!response.ok || !response.body ||
        !response.headers.get("content-type")?.includes("json") ||
        Number(response.headers.get("content-length")) > MAX_BYTES) return;
    const reader = response.clone().body.getReader();
    const decoder = new TextDecoder();
    let body = "";
    let bytes = 0;
    try {
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        bytes += value.byteLength;
        if (bytes > MAX_BYTES) {
          void reader.cancel().catch(() => {});
          return;
        }
        body += decoder.decode(value, { stream: true });
      }
      body += decoder.decode();
      accept(JSON.parse(body));
    } catch { /* Ignore failed responses; never treat a draft or error as a reply. */ }
    finally { reader.releaseLock(); }
  }

  const originalFetch = window.fetch;
  window.fetch = function (...args) {
    const request = args[0];
    const url = typeof request === "string" || request instanceof URL ? String(request) : request?.url;
    const responsePromise = Reflect.apply(originalFetch,this,args);
    if (relevantUrl(url)) void responsePromise.then(readResponse).catch(() => {});
    return responsePromise;
  };

  const requestUrls = new WeakMap();
  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method,url,...rest) {
    requestUrls.set(this, relevantUrl(url));
    return Reflect.apply(originalOpen,this,[method,url,...rest]);
  };
  XMLHttpRequest.prototype.send = function (...args) {
    if (requestUrls.get(this)) {
      this.addEventListener("load", () => {
        if (this.status < 200 || this.status >= 300) return;
        try {
          if (this.responseType === "json") accept(this.response);
          else if ((!this.responseType || this.responseType === "text") &&
                   this.responseText.length <= MAX_BYTES) accept(JSON.parse(this.responseText));
        } catch { /* Non-JSON responses are unrelated to reply evidence. */ }
      }, { once:true });
    }
    return Reflect.apply(originalSend,this,args);
  };
})();
