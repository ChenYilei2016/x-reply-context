(() => {
  "use strict";
  const core = globalThis.XReplyContext;
  const CHANNEL = "x-reply-context-v1";
  const MAX_BYTES = 8 * 1024 * 1024;
  const pendingUsers = new Map();
  const pendingTweets = new Map();
  const pendingLikes = new Map();
  let ready = false;
  let timer;

  function operationFor(value) {
    try {
      const url = new URL(value, location.href);
      if (url.origin !== location.origin) return "";
      if (/^\/i\/api\/2\/notifications\/(?:all|mentions|verified)\.json$/.test(url.pathname)) return "Notifications";
      return url.pathname.match(/^\/i\/api\/graphql\/[\w-]+\/(TweetDetail|TweetResultByRestId|TweetResultsByRestIds|UserTweets|UserTweetsAndReplies|UserByScreenName|HomeTimeline|HomeLatestTimeline|SearchTimeline|CreateTweet|Likes|FavoriteTweet|UnfavoriteTweet)$/)?.[1] || "";
    } catch { return ""; }
  }

  function currentAccount() {
    const path = document.querySelector('a[data-testid="AppTabBar_Profile_Link"]')?.getAttribute("href");
    return core.handle(path?.match(/^\/([a-zA-Z0-9_]{1,15})\/?$/)?.[1]);
  }

  function requestContext(url) {
    const operation = operationFor(url);
    if (!operation) return null;
    return {
      operation, account:currentAccount(), observedAt:Date.now(),
      reaction:operation === "FavoriteTweet" || operation === "UnfavoriteTweet"
    };
  }

  function reactionId(body) {
    try {
      if (typeof body !== "string" || body.length > 4096) return "";
      return core.id(JSON.parse(body)?.variables?.tweet_id);
    } catch { return ""; }
  }

  function flush() {
    timer = undefined;
    if (!ready || (!pendingTweets.size && !pendingUsers.size && !pendingLikes.size)) return;
    window.postMessage({
      channel: CHANNEL, type: "OBSERVED",
      batch: {
        users:[...pendingUsers.values()], tweets:[...pendingTweets.values()], likes:[...pendingLikes.values()]
      }
    }, location.origin);
    pendingUsers.clear();
    pendingTweets.clear();
    pendingLikes.clear();
  }

  async function accept(payload,context) {
    try {
      const batch = core.extract(payload);
      let likes = batch.likes;
      if (context.reaction) {
        const responseAt = Date.now();
        const tweetId = await context.tweetId;
        const key = context.operation === "FavoriteTweet" ? "favorite_tweet" : "unfavorite_tweet";
        likes = !payload.errors?.length && payload.data?.[key] === "Done" && tweetId ?
          [{ id:tweetId,liked:context.operation === "FavoriteTweet",observedAt:responseAt }] : [];
      }
      for (const user of batch.users) {
        if (pendingUsers.size < 500 || pendingUsers.has(user.id)) pendingUsers.set(user.id,user);
      }
      for (const tweet of batch.tweets) {
        if (pendingTweets.size < 500 || pendingTweets.has(tweet.id)) pendingTweets.set(tweet.id,tweet);
      }
      // Like state belongs to the viewer, not the tweet author; discard it across an account switch.
      if (context.account && context.account === currentAccount()) {
        for (const like of likes) {
          const key = `${context.account}:${like.id}`;
          const record = {
            ...like,account:context.account,observedAt:like.observedAt || context.observedAt,
            source:context.reaction ? "mutation" : "snapshot"
          };
          const previous = pendingLikes.get(key);
          if (previous && (previous.observedAt > record.observedAt ||
              (previous.observedAt === record.observedAt && previous.source === "mutation" && !context.reaction))) continue;
          if (pendingLikes.size < 500 || previous) pendingLikes.set(key,record);
        }
      }
      if (!timer) timer = setTimeout(flush,200);
    } catch {
      // A changed X response must not interfere with the original request.
    }
  }

  window.addEventListener("message", event => {
    if (event.source === window && event.origin === location.origin &&
        event.data?.channel === CHANNEL && event.data.type === "READY") {
      ready = true;
      flush();
    }
  });
  window.postMessage({ channel:CHANNEL,type:"OBSERVER_READY" },location.origin);

  async function readResponse(response,context) {
    if (!response.ok || !response.body ||
        !response.headers.get("content-type")?.includes("json") ||
        Number(response.headers.get("content-length")) > MAX_BYTES) return;
    const reader = response.clone().body.getReader();
    const decoder = new TextDecoder();
    let body = "";
    let bytes = 0;
    try {
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        bytes += value.byteLength;
        if (bytes > MAX_BYTES) {
          void reader.cancel().catch(() => {});
          return;
        }
        body += decoder.decode(value, { stream: true });
      }
      body += decoder.decode();
      await accept(JSON.parse(body),context);
    } catch { /* Ignore failed responses; never treat a draft or error as a reply. */ }
    finally { reader.releaseLock(); }
  }

  const originalFetch = window.fetch;
  window.fetch = function (...args) {
    const request = args[0];
    const url = typeof request === "string" || request instanceof URL ? String(request) : request?.url;
    const context = requestContext(url);
    if (context?.reaction) {
      if (args[1]?.body !== undefined) context.tweetId = reactionId(args[1].body);
      else if (typeof Request !== "undefined" && request instanceof Request) {
        // Read only the target ID from a cloned like request; leave the original body untouched.
        try { context.tweetId = request.clone().text().then(reactionId,() => ""); }
        catch { context.tweetId = ""; }
      }
    }
    const responsePromise = Reflect.apply(originalFetch,this,args);
    if (context) void responsePromise.then(response => readResponse(response,context)).catch(() => {});
    return responsePromise;
  };

  const requestContexts = new WeakMap();
  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method,url,...rest) {
    requestContexts.set(this,requestContext(url));
    return Reflect.apply(originalOpen,this,[method,url,...rest]);
  };
  XMLHttpRequest.prototype.send = function (...args) {
    const context = requestContexts.get(this);
    if (context) {
      context.account = currentAccount();
      context.observedAt = Date.now();
      if (context.reaction) context.tweetId = reactionId(args[0]);
      this.addEventListener("load", () => {
        if (this.status < 200 || this.status >= 300) return;
        try {
          if (this.responseType === "json") void accept(this.response,context);
          else if ((!this.responseType || this.responseType === "text") &&
                   this.responseText.length <= MAX_BYTES) void accept(JSON.parse(this.responseText),context);
        } catch { /* Non-JSON responses are unrelated to reply evidence. */ }
      }, { once:true });
    }
    return Reflect.apply(originalSend,this,args);
  };
})();
