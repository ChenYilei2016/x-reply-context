(() => {
  "use strict";
  const MAX_SCRIPTS = 64;
  const PREFIX_CHARS = 256;
  const MAX_SCRIPT_CHARS = 256 * 1024;
  const assignment = /^\s*window\.__INITIAL_STATE__\s*=\s*(?=\{)/;
  const core = globalThis.XReplyContext;

  function identity(state) {
    const id = core.id(state?.session?.user_id);
    const user = id && state?.entities?.users?.entities?.[id];
    const account = core.handle(user?.screen_name || user?.core?.screen_name);
    return id && account && core.id(user?.id_str || user?.rest_id) === id ? {id,account} : null;
  }

  function parseIdentity(source,start) {
    let depth = 0, quoted = false, escaped = false;
    for (let index=start;index<source.length;index++) {
      const char = source[index];
      if (quoted) {
        if (escaped) escaped=false;
        else if (char === "\\") escaped=true;
        else if (char === '"') quoted=false;
      } else if (char === '"') quoted=true;
      else if (char === "{") depth++;
      else if (char === "}" && --depth === 0) {
        if (!/^\s*(?:;|$)/.test(source.slice(index+1,index+33))) return null;
        // Only the JSON literal is decoded; trailing JavaScript is never executed.
        return identity(JSON.parse(source.slice(start,index+1)));
      }
    }
    return null;
  }

  function fromScripts() {
    const scripts = document.scripts;
    if (!scripts) return null;
    for (let index=0,length=Math.min(scripts.length,MAX_SCRIPTS);index<length;index++) {
      const script = scripts[index];
      if (!script || script.hasAttribute("src")) continue;
      const type=(script.type || "").trim().toLowerCase();
      if (type && type !== "text/javascript" && type !== "application/javascript") continue;
      const nodes = script.childNodes;
      if (nodes.length !== 1 || nodes[0].nodeType !== 3) continue;
      const node = nodes[0];
      if (!Number.isSafeInteger(node.length) || node.length < 1) continue;
      // Inspect a bounded prefix before copying any full text, including oversized scripts.
      const prefix = node.substringData(0,Math.min(PREFIX_CHARS,node.length));
      const match = assignment.exec(prefix);
      if (!match) continue;
      if (node.length > MAX_SCRIPT_CHARS) return null;
      return parseIdentity(node.data,match[0].length);
    }
    return null;
  }

  function create() {
    let finished = false, result = null;
    return {
      read(allowScripts = false) {
        if (finished) return result;
        try {
          const state = window.__INITIAL_STATE__;
          if (state != null) {
            result = identity(state);
            if (result || allowScripts) finished=true;
            return result; // An existing but invalid global must not be replaced by older script data.
          }
          if (!allowScripts) return null;
          finished=true;
          result=fromScripts();
          return result;
        } catch { if (allowScripts) finished=true; return null; }
      },
      stop() {finished=true;result=null;}
    };
  }
  globalThis.XReplyStartupAccount = {create};
})();
