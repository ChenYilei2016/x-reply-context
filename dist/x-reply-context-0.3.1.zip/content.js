(() => {
  "use strict";
  const CHANNEL = "x-reply-context-v1";
  let timer;
  let running = false;
  let again = false;
  let lastAccount = "";
  let lastSignature = "";
  const pending = [];

  function accountHandle() {
    const profile = document.querySelector('a[data-testid="AppTabBar_Profile_Link"]');
    return profile?.getAttribute("href")?.match(/^\/([a-zA-Z0-9_]{1,15})\/?$/)?.[1]?.toLowerCase() || "";
  }

  function tweetId(article) {
    const time = article.querySelector("time");
    return time?.closest("a")?.getAttribute("href")?.match(/\/status\/(\d+)/)?.[1] || "";
  }

  function schedule() {
    if (timer) return;
    timer = setTimeout(() => { timer = undefined; void refresh(); },250);
  }

  async function message(payload) {
    const reply = await chrome.runtime.sendMessage(payload);
    if (!reply?.ok) throw new Error(reply?.error || "扩展连接已断开，请刷新页面");
    return reply;
  }

  function link(label, id, title) {
    const anchor = document.createElement("a");
    anchor.textContent = label;
    anchor.href = `https://x.com/i/status/${id}`;
    anchor.target = "_blank";
    anchor.rel = "noopener noreferrer";
    if (title) anchor.title = title;
    return anchor;
  }

  function render(article, result) {
    article.dataset.xrcId = result.id;
    let bar = article.querySelector(".xrc-labels");
    if (["self","not-reply"].includes(result.status)) {
      bar?.remove();
      return;
    }
    const signature = JSON.stringify(result);
    if (bar?.dataset.signature === signature) return;
    if (!bar) {
      bar = document.createElement("div");
      bar.className = "xrc-labels";
      bar.setAttribute("aria-label","回过了 · 对话提示");
      bar.addEventListener("click",event => event.stopPropagation());
      const anchor = article.querySelector('[data-testid="tweetText"]') ||
        article.querySelector('[role="group"]');
      if (!anchor) return;
      anchor.before(bar);
    }
    bar.dataset.signature = signature;
    bar.dataset.origin = result.origin;
    const origin = document.createElement("span");
    origin.className = "xrc-origin";
    origin.textContent = { mine:"我原帖", others:"别人原帖", unknown:"原帖待确认" }[result.origin];
    origin.title = result.rootHandle ?
      `原帖作者 @${result.rootHandle}；按整段对话最初的帖子判断，楼中楼沿用原帖归属。` :
      "尚未读取到原帖作者，暂不判断归属。";
    const labels = [origin];
    const status = result.evidenceId ? link("文字-已回",result.evidenceId,result.evidenceText) :
      document.createElement("span");
    status.className = "xrc-status";
    status.dataset.confirmed = String(Boolean(result.evidenceId));
    if (!result.evidenceId) status.textContent = "文字-待确认";
    status.title = result.status === "replied" ?
      `你在同一原帖里已经回复过这个人。点击查看：${result.evidenceText || "我的回复"}` :
      "当前本地记录还没有确认你回过此人，不代表你从未回复。";
    const heart = result.likeEvidenceId ? link("红心-已点",result.likeEvidenceId) : document.createElement("span");
    heart.className = "xrc-heart";
    heart.dataset.confirmed = String(Boolean(result.likeEvidenceId));
    if (!result.likeEvidenceId) heart.textContent = "红心-待确认";
    heart.title = result.likeEvidenceId ?
      (result.likeEvidenceId === result.id ?
        "已给这条帖子点过红心。点击查看；若是旧记录，状态以 X 当前显示为准。" :
        "已给这个人在同一原帖中的另一条帖子点过红心。点击查看依据；若是旧记录，状态以 X 当前显示为准。") :
      "当前记录没有确认你给这个人在同一原帖中点过红心，不代表从未点赞。";
    labels.push(status,heart);
    if (result.personStats) {
      for (const [label,count,description] of [
        ["我评他",result.personStats.myCommentedPosts,"你评论过他的几篇原帖"],
        ["他评我",result.personStats.theirCommentedPosts,"他评论过你的几篇原帖"]
      ]) {
        const badge = document.createElement("span");
        badge.className = "xrc-person";
        badge.textContent = `${label} ${count}`;
        badge.title = `${description}。同一篇下多次评论（含楼中楼）只算 1 篇；在自己或第三方原帖下回话、点赞均不计。只统计本地保留且已确认原帖作者的记录。`;
        labels.push(badge);
      }
    }
    labels.push(result.rootId ? link("原帖",result.rootId) : link("查看上下文",result.id));
    const main = document.createElement("div");
    main.className = "xrc-main-labels";
    main.replaceChildren(...labels);
    bar.replaceChildren(main);
    if (result.newPerson) {
      const badge = document.createElement("strong");
      badge.className = "xrc-new-person";
      badge.textContent = "NEW";
      badge.title = "这条是本地记录中他第一次评论你的原帖，且“我评他”为 0。仅第一条评论通知标新，后续不重复；点赞、你在自己原帖下回他不影响 NEW。只依据本地已读取记录，不保证覆盖完整历史。";
      bar.append(badge);
    }
  }

  function showGuide(account, replyCount, likeCount) {
    const column = document.querySelector('[data-testid="primaryColumn"]');
    const timeline = column?.querySelector('section[role="region"]');
    if (!timeline) return;
    let guide = column.querySelector(".xrc-guide");
    if (!guide) {
      guide = document.createElement("aside");
      guide.className = "xrc-guide";
      guide.setAttribute("aria-label","回过了 · 使用提示");
      timeline.before(guide);
    }
    const signature = `${account}:${replyCount}:${likeCount}`;
    if (guide.dataset.signature === signature) return;
    guide.dataset.signature = signature;
    const title = document.createElement("strong");
    title.textContent = `回过了 · ${replyCount} 组文字回复 · ${likeCount} 条红心记录`;
    const hint = document.createElement("span");
    hint.textContent = "数字按原帖去重；NEW：首次评论我的原帖，且我评他为 0。";
    const history = document.createElement("a");
    history.href = `https://x.com/${account}/with_replies`;
    history.target = "_blank";
    history.rel = "noopener noreferrer";
    history.textContent = "打开我的回复，补充历史";
    history.title = "打开后向下浏览近期回复，扩展会记住已加载的真实回复。";
    const rules = document.createElement("details");
    rules.className = "xrc-rules";
    const summary = document.createElement("summary");
    summary.textContent = "统计口径";
    rules.append(summary);
    for (const text of [
      "我原帖 / 别人原帖：按整段对话最初的帖子判断，楼中楼沿用原帖归属。",
      "我评他：我评论过他的几篇原帖；他评我：他评论过我的几篇原帖。同一篇下评论多次（含楼中楼）只算 1 篇。在自己或第三方原帖下回话、点赞不增加对应方向的数字。",
      "NEW：这条是他第一次评论我的原帖，且“我评他”为 0。只标第一条评论通知，后续不重复；点赞或我在自己原帖下回他不影响 NEW。我评论过他的原帖后，不再标 NEW。",
      "文字-已回 / 红心-已点：在同一原帖、同一个人范围内分别查找我的文字回复和点赞依据，不跨原帖沿用。点击标签可查看依据。",
      "所有判断仅依据本地已读取记录；原帖作者未确认时不计入原帖数。0 或“待确认”不代表历史上从未操作。各类记录最多 10,000 条，保留 90 天，淘汰后统计可能减少，不额外抓取完整历史。"
    ]) {
      const paragraph = document.createElement("p");
      paragraph.textContent = text;
      rules.append(paragraph);
    }
    guide.replaceChildren(title,hint,history,rules);
  }

  async function refresh() {
    if (running) { again = true; return; }
    running = true;
    try {
      const account = accountHandle();
      if (!account) return;
      if (account !== lastAccount) {
        document.querySelectorAll(".xrc-labels,.xrc-guide").forEach(node => node.remove());
        lastAccount = account;
        lastSignature = "";
      }
      if (pending.length) {
        const batches = pending.splice(0);
        for (const batch of batches) await message({ type:"INGEST",batch,account });
        lastSignature = "";
      }
      if (!/^\/notifications(?:\/|$)/.test(location.pathname)) {
        document.querySelectorAll(".xrc-labels,.xrc-guide").forEach(node => node.remove());
        lastSignature = "";
        return;
      }
      const articles = Array.from(document.querySelectorAll('article[data-testid="tweet"]')).slice(0,100);
      const ids = articles.map(tweetId);
      const signature = account + ":" + ids.join(",");
      if (signature === lastSignature && articles.every(article => article.dataset.xrcId === tweetId(article))) return;
      const result = await message({ type:"CLASSIFY",account,ids:ids.filter(Boolean) });
      if (accountHandle() !== account || !/^\/notifications(?:\/|$)/.test(location.pathname)) return;
      const byId = new Map(result.rows.map(row => [row.id,row]));
      for (const article of articles) {
        const row = byId.get(tweetId(article));
        if (article.isConnected && row) render(article,row);
      }
      showGuide(account,result.replyCount,result.likeCount || 0);
      lastSignature = signature;
    } catch (error) {
      const guide = document.querySelector(".xrc-guide");
      if (guide) { guide.textContent = error.message; guide.dataset.signature = ""; }
    } finally {
      running = false;
      if (again) { again = false; schedule(); }
    }
  }

  window.addEventListener("message", event => {
    if (event.source !== window || event.origin !== location.origin ||
        event.data?.channel !== CHANNEL) return;
    if (event.data.type === "OBSERVER_READY") {
      window.postMessage({ channel:CHANNEL,type:"READY" },location.origin);
      return;
    }
    if (event.data.type !== "OBSERVED") return;
    if (pending.length < 10) pending.push(event.data.batch);
    schedule();
  });
  chrome.runtime.onMessage.addListener((request,_sender,respond) => {
    if (request?.type === "GET_ACCOUNT") respond({ account:accountHandle() });
  });
  chrome.storage.onChanged.addListener((changes,area) => {
    if (area === "local" && changes.replyContext) { lastSignature = ""; schedule(); }
  });
  const observer = new MutationObserver(records => {
    if (records.some(record => !record.target.closest?.(".xrc-labels,.xrc-guide"))) schedule();
  });
  observer.observe(document,{ childList:true,subtree:true });
  window.addEventListener("popstate",schedule);
  document.addEventListener("visibilitychange",() => { if (!document.hidden) schedule(); });
  window.postMessage({ channel:CHANNEL,type:"READY" },location.origin);
  schedule();
})();
